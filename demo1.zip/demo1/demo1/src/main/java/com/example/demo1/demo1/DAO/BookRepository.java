package com.example.demo1.demo1.DAO;

import com.example.demo1.demo1.Entity.Book;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface BookRepository  extends MongoRepository<Book, Integer> {
}
